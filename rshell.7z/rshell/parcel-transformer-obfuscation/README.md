This [Parcel](https://parceljs.org/) plugin aims to obfuscate JavaScript assets as part of the netlify build process.
