---
functions:
  shell:
    - code: valgrind /bin/sh
  sudo:
    - code: sudo valgrind /bin/sh
---
